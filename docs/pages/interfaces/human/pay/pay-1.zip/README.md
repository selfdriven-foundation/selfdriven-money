# selfdriven.money/pay

Non-custodial Cardano (ADA) payment gateway with KERI cryptographic identity layer.

## Quick Start

```bash
npm install
npm start
# → http://localhost:3000
```

### Environment Variables

| Variable | Description | Default |
|---|---|---|
| `PORT` | Server port | `3000` |
| `BLOCKFROST_API_KEY` | Blockfrost API key for mainnet monitoring | Mock mode |
| `BLOCKFROST_API_URL` | Blockfrost base URL | `https://cardano-mainnet.blockfrost.io/api/v0` |
| `MASTER_API_KEY` | Master API key for initial access | `sd_live_MASTER_KEY_CHANGE_ME` |
| `CORS_ORIGIN` | Allowed CORS origin | `*` |
| `POLL_INTERVAL` | Payment monitor interval (ms) | `30000` |

### With Blockfrost (real Cardano monitoring)

```bash
BLOCKFROST_API_KEY=mainnetXXXXXX npm start
```

## Architecture

```
selfdriven-pay/
├── server.js              # Express API server (all endpoints)
├── public/
│   └── index.html         # Dashboard + checkout frontend
├── lib/
│   ├── keri.js            # KERI event generator (icp, ixn, dip)
│   ├── cardano.js         # Blockfrost integration + price oracle
│   ├── store.js           # In-memory store with JSON persistence
│   └── webhooks.js        # HMAC-signed webhook delivery + retries
├── data.json              # Persisted data (auto-created)
└── package.json
```

## API Reference

Base URL: `http://localhost:3000/api/v1`

Authentication: `Authorization: Bearer sd_live_...`

### Public Endpoints

| Method | Path | Description |
|---|---|---|
| `GET` | `/health` | Service health check |
| `GET` | `/api/v1/prices` | Current ADA/fiat prices |
| `GET` | `/api/v1/checkout/:id` | Customer-facing payment details |
| `GET` | `/api/v1/checkout/:id/qr` | QR code image (PNG/SVG) |
| `GET` | `/api/v1/checkout/:id/status` | Poll payment status |

### Authenticated Endpoints

#### Payments

```bash
# Create payment
curl -X POST http://localhost:3000/api/v1/payments \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 250,
    "currency": "ADA",
    "description": "Invoice #1042",
    "expiry_minutes": 30,
    "metadata": {"orderId": "ORD-1042"}
  }'

# List payments
curl http://localhost:3000/api/v1/payments?status=confirmed&limit=10 \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"

# Get payment
curl http://localhost:3000/api/v1/payments/pay_XXXX \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"

# Confirm payment (manual/testing)
curl -X POST http://localhost:3000/api/v1/payments/pay_XXXX/confirm \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME" \
  -H "Content-Type: application/json" \
  -d '{"tx_hash": "abc123..."}'

# Expire payment
curl -X POST http://localhost:3000/api/v1/payments/pay_XXXX/expire \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"
```

#### API Keys

```bash
# Create API key (returns secret once)
curl -X POST http://localhost:3000/api/v1/api-keys \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME" \
  -H "Content-Type: application/json" \
  -d '{"name": "Production", "test_mode": false}'

# List keys
curl http://localhost:3000/api/v1/api-keys \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"

# Delete key
curl -X DELETE http://localhost:3000/api/v1/api-keys/key_XXXX \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"
```

#### Webhooks

```bash
# Create webhook (returns signing secret once)
curl -X POST http://localhost:3000/api/v1/webhooks \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://yoursite.com/webhook", "events": ["payment.confirmed"]}'

# Test webhook
curl -X POST http://localhost:3000/api/v1/webhooks/whk_XXXX/test \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"
```

#### Settings, Stats & KERI

```bash
# Get/update settings
curl http://localhost:3000/api/v1/settings \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"

# Dashboard stats
curl http://localhost:3000/api/v1/stats \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"

# KERI Key Event Log
curl http://localhost:3000/api/v1/identity/kel \
  -H "Authorization: Bearer sd_live_MASTER_KEY_CHANGE_ME"
```

## KERI Identity Layer

Every payment mutation is anchored as a KERI interaction event (`ixn`) in the merchant's Key Event Log:

- **Payment created** → `ixn` with action `created`
- **Payment confirmed** → `ixn` with action `confirmed` + tx_hash
- **Payment expired** → `ixn` with action `expired`
- **API key generated** → `dip` (delegated inception) for agent AID
- **Settings changed** → `ixn` with action `settings_updated`

Webhook payloads include the KERI event for independent verification.

## Webhook Signature Verification

```javascript
const crypto = require('crypto');

function verifyWebhook(body, signature, secret) {
  const expected = crypto.createHmac('sha256', secret)
    .update(body)
    .digest('hex');
  return signature === expected;
}

// In your webhook handler:
app.post('/webhook', (req, res) => {
  const sig = req.headers['x-sd-signature'];
  const valid = verifyWebhook(JSON.stringify(req.body), sig, 'whsec_...');
  if (!valid) return res.status(401).send('Invalid signature');
  // Process event...
});
```

## License

selfdriven Foundation · selfdriven.money/pay
