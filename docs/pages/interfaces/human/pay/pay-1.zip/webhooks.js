// ═══════════════════════════════════════════════════════════════
// lib/webhooks.js — Webhook delivery with HMAC signing & retries
// Delivers payment events to merchant-configured endpoints with
// HMAC-SHA256 signatures for verification.
// ═══════════════════════════════════════════════════════════════
const crypto = require('crypto');
let fetch;
try { fetch = require('node-fetch'); } catch { fetch = globalThis.fetch; }

const store = require('./store');

const MAX_RETRIES = 3;
const RETRY_DELAYS = [1000, 5000, 30000]; // ms

/**
 * Sign a webhook payload with HMAC-SHA256
 */
function signPayload(payload, secret) {
  const body = typeof payload === 'string' ? payload : JSON.stringify(payload);
  return crypto.createHmac('sha256', secret).update(body).digest('hex');
}

/**
 * Deliver a webhook event to a single endpoint
 */
async function deliverToEndpoint(webhook, event, attempt = 0) {
  const body = JSON.stringify(event);
  const signature = signPayload(body, webhook.secret);
  const timestamp = Date.now().toString();

  try {
    const res = await fetch(webhook.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-SD-Signature': signature,
        'X-SD-Timestamp': timestamp,
        'X-SD-Event': event.event,
        'X-SD-Delivery': event.deliveryId || crypto.randomBytes(8).toString('hex'),
        'User-Agent': 'selfdriven-pay/1.0',
      },
      body,
      timeout: 10000,
    });

    const success = res.status >= 200 && res.status < 300;
    store.updateWebhook(webhook.id, {
      lastDelivery: new Date().toISOString(),
      lastStatus: res.status,
      failCount: success ? 0 : webhook.failCount + 1,
    });

    if (!success && attempt < MAX_RETRIES) {
      console.warn(`[webhooks] Delivery to ${webhook.url} failed (${res.status}), retry ${attempt + 1}/${MAX_RETRIES}`);
      setTimeout(() => deliverToEndpoint(webhook, event, attempt + 1), RETRY_DELAYS[attempt]);
    } else if (!success) {
      console.error(`[webhooks] Delivery to ${webhook.url} permanently failed after ${MAX_RETRIES} retries`);
      if (webhook.failCount >= 10) {
        store.updateWebhook(webhook.id, { active: false });
        console.warn(`[webhooks] Disabled webhook ${webhook.id} after 10 consecutive failures`);
      }
    } else {
      console.log(`[webhooks] Delivered ${event.event} to ${webhook.url}`);
    }

    return success;
  } catch (e) {
    console.warn(`[webhooks] Delivery error to ${webhook.url}:`, e.message);
    if (attempt < MAX_RETRIES) {
      setTimeout(() => deliverToEndpoint(webhook, event, attempt + 1), RETRY_DELAYS[attempt]);
    }
    return false;
  }
}

/**
 * Dispatch a payment event to all matching webhooks
 */
async function dispatch(eventType, payment, extra = {}) {
  const webhooks = store.getWebhooksByEvent(eventType, payment.merchantId);
  if (webhooks.length === 0) return;

  const event = {
    event: eventType,
    deliveryId: crypto.randomBytes(8).toString('hex'),
    payment_id: payment.id,
    amount: payment.amountAda || payment.amount,
    currency: payment.currency,
    description: payment.description,
    status: payment.status,
    tx_hash: payment.txHash,
    confirmations: payment.confirmations || 0,
    address: payment.address,
    metadata: payment.metadata,
    keriEvent: payment.keriEvent,
    createdAt: payment.createdAt,
    updatedAt: payment.updatedAt,
    ...extra,
  };

  console.log(`[webhooks] Dispatching ${eventType} for ${payment.id} to ${webhooks.length} endpoint(s)`);

  const results = await Promise.allSettled(
    webhooks.map(wh => deliverToEndpoint(wh, event))
  );

  return results.map((r, i) => ({
    webhookId: webhooks[i].id,
    url: webhooks[i].url,
    success: r.status === 'fulfilled' && r.value === true,
  }));
}

module.exports = {
  signPayload,
  deliverToEndpoint,
  dispatch,
};
