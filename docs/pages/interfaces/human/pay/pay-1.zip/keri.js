// ═══════════════════════════════════════════════════════════════
// lib/keri.js — KERI Event Generator for selfdriven.money/pay
// Generates deterministic KERI interaction (ixn), inception (icp),
// and delegation (dip) events for payment anchoring.
// ═══════════════════════════════════════════════════════════════
const crypto = require('crypto');

// Default merchant AID — in production this comes from the KERI wallet
const DEFAULT_AID = 'EKE4g_0hDGBOqDLKzNBT3kFOPxoP7wXkqt';

// Sequence number tracker (in production: read from KEL)
let sequenceCounter = Date.now();

/**
 * Generate a SHA-256 digest of arbitrary data
 */
function digest(data) {
  return crypto.createHash('sha256')
    .update(typeof data === 'string' ? data : JSON.stringify(data))
    .digest('hex');
}

/**
 * Generate a KERI-compatible Self-Addressing Identifier
 * In production: derived from inception event key commitment
 */
function generateAID() {
  const seed = crypto.randomBytes(32);
  const hash = crypto.createHash('sha256').update(seed).digest('base64url');
  return `E${hash.substring(0, 31)}`;
}

/**
 * Create a KERI inception event (icp) for a new merchant
 */
function createInceptionEvent(merchantId, opts = {}) {
  const aid = generateAID();
  const now = Date.now();
  const event = {
    v: 'KERI10JSON',
    t: 'icp',
    d: '', // self-addressing digest — filled below
    i: aid,
    s: '0',
    kt: opts.threshold || '1',
    k: [aid], // signing keys (simplified)
    nt: '1',
    n: [digest(crypto.randomBytes(32).toString('hex'))], // next key commitment (pre-rotation)
    bt: opts.witnessThreshold || '2',
    b: opts.witnesses || [
      'BGKVzj4ve0VSd8z_AmvhLg0lqcE2l_E5_Lb0lTV7GmME',
      'BuyRFMideczFZoapylLIyCjSdhtqVb31wZkRKvPFNTkw3',
      'Bgoq68HCmYNUDgOz4Skvlu306o_NY-NrYuKAVhk3Zh9c',
    ],
    c: [],
    a: [],
    di: '',
    _metadata: {
      merchantId,
      purpose: 'payment-gateway',
      created: new Date(now).toISOString(),
    },
  };
  event.d = digest(event);
  return { aid, event };
}

/**
 * Create a KERI interaction event (ixn) to anchor a payment
 * This is the core event type for payment operations
 */
function createInteractionEvent(aid, paymentData) {
  sequenceCounter++;
  const sn = sequenceCounter;
  const anchor = {
    paymentId: paymentData.paymentId,
    amount: paymentData.amount,
    currency: paymentData.currency || 'ADA',
    action: paymentData.action, // 'created', 'confirmed', 'expired', 'refunded'
    txHash: paymentData.txHash || null,
    timestamp: new Date().toISOString(),
  };

  const event = {
    v: 'KERI10JSON',
    t: 'ixn',
    d: '', // self-addressing
    i: aid || DEFAULT_AID,
    s: sn.toString(),
    p: paymentData.previousDigest || digest(sn.toString()),
    a: [
      {
        i: paymentData.paymentId,
        s: '0',
        d: digest(anchor),
      }
    ],
    _anchor: anchor,
  };
  event.d = digest(event);

  return {
    type: 'ixn',
    aid: event.i,
    sn,
    digest: event.d,
    anchor,
    event,
  };
}

/**
 * Create a KERI delegated inception event (dip) for an API key / agent
 */
function createDelegatedInceptionEvent(delegatorAid, agentLabel) {
  const agentAid = generateAID();
  const now = Date.now();
  const event = {
    v: 'KERI10JSON',
    t: 'dip',
    d: '',
    i: agentAid,
    s: '0',
    kt: '1',
    k: [agentAid],
    nt: '1',
    n: [digest(crypto.randomBytes(32).toString('hex'))],
    bt: '2',
    b: [
      'BGKVzj4ve0VSd8z_AmvhLg0lqcE2l_E5_Lb0lTV7GmME',
      'BuyRFMideczFZoapylLIyCjSdhtqVb31wZkRKvPFNTkw3',
      'Bgoq68HCmYNUDgOz4Skvlu306o_NY-NrYuKAVhk3Zh9c',
    ],
    c: [],
    a: [],
    di: delegatorAid,
    _metadata: {
      label: agentLabel,
      scope: 'payment-api',
      created: new Date(now).toISOString(),
    },
  };
  event.d = digest(event);
  return { agentAid, event };
}

/**
 * Verify a KERI event digest (simplified)
 */
function verifyEventDigest(event) {
  const { d, ...rest } = event;
  return d === digest({ d: '', ...rest });
}

module.exports = {
  DEFAULT_AID,
  digest,
  generateAID,
  createInceptionEvent,
  createInteractionEvent,
  createDelegatedInceptionEvent,
  verifyEventDigest,
};
