// ═══════════════════════════════════════════════════════════════
// lib/cardano.js — Cardano blockchain integration
// Uses Blockfrost API for address monitoring, tx lookup, and
// ADA/fiat price conversion. Falls back to mock data when
// no API key is configured.
// ═══════════════════════════════════════════════════════════════
const crypto = require('crypto');
let fetch;
try { fetch = require('node-fetch'); } catch { fetch = globalThis.fetch; }

const BLOCKFROST_API = process.env.BLOCKFROST_API_URL || 'https://cardano-mainnet.blockfrost.io/api/v0';
const BLOCKFROST_KEY = process.env.BLOCKFROST_API_KEY || '';

// ─── Price Cache ─────────────────────────────────────
let priceCache = { ada_usd: 0.70, ada_aud: 1.10, ada_eur: 0.65, ada_gbp: 0.56, updatedAt: 0 };

async function fetchPrice() {
  // Refresh at most every 60s
  if (Date.now() - priceCache.updatedAt < 60000) return priceCache;

  try {
    // Use CoinGecko free API
    const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=cardano&vs_currencies=usd,aud,eur,gbp');
    if (res.ok) {
      const data = await res.json();
      priceCache = {
        ada_usd: data.cardano?.usd || 0.70,
        ada_aud: data.cardano?.aud || 1.10,
        ada_eur: data.cardano?.eur || 0.65,
        ada_gbp: data.cardano?.gbp || 0.56,
        updatedAt: Date.now(),
      };
    }
  } catch (e) {
    console.warn('[cardano] Price fetch failed, using cached:', e.message);
  }
  return priceCache;
}

/**
 * Convert fiat amount to ADA
 */
async function fiatToAda(amount, currency) {
  const prices = await fetchPrice();
  const key = `ada_${currency.toLowerCase()}`;
  const rate = prices[key];
  if (!rate) throw new Error(`Unsupported currency: ${currency}`);
  return Math.round((amount / rate) * 1000000) / 1000000; // 6 decimal ADA
}

/**
 * Convert ADA amount to fiat
 */
async function adaToFiat(adaAmount, currency = 'USD') {
  const prices = await fetchPrice();
  const key = `ada_${currency.toLowerCase()}`;
  const rate = prices[key];
  if (!rate) return null;
  return Math.round(adaAmount * rate * 100) / 100;
}

/**
 * Get current ADA prices
 */
async function getPrices() {
  return fetchPrice();
}

/**
 * Generate a unique Cardano address for a payment.
 * In production: derive from merchant's HD wallet using payment index.
 * Here we generate a deterministic mock address from the payment ID.
 */
function generatePaymentAddress(paymentId, merchantAddress) {
  // In production, use BIP-44 derivation from merchant's xpub:
  // m/1852'/1815'/0'/0/{index}
  // For now, return a deterministic address based on merchant + paymentId
  if (merchantAddress) return merchantAddress;

  const hash = crypto.createHash('sha256')
    .update(paymentId + Date.now().toString())
    .digest('hex');
  // Construct a realistic-looking Shelley address
  return `addr1q${hash.substring(0, 54)}q${hash.substring(54, 60)}`;
}

/**
 * Check for transactions at an address via Blockfrost
 */
async function getAddressTransactions(address) {
  if (!BLOCKFROST_KEY) {
    return { mock: true, transactions: [] };
  }

  try {
    const res = await fetch(`${BLOCKFROST_API}/addresses/${address}/transactions?order=desc&count=10`, {
      headers: { 'project_id': BLOCKFROST_KEY },
    });
    if (res.status === 404) return { mock: false, transactions: [] };
    if (!res.ok) throw new Error(`Blockfrost ${res.status}`);
    const txs = await res.json();
    return { mock: false, transactions: txs };
  } catch (e) {
    console.warn('[cardano] Blockfrost query failed:', e.message);
    return { mock: true, transactions: [] };
  }
}

/**
 * Get transaction details from Blockfrost
 */
async function getTransaction(txHash) {
  if (!BLOCKFROST_KEY) return null;
  try {
    const res = await fetch(`${BLOCKFROST_API}/txs/${txHash}`, {
      headers: { 'project_id': BLOCKFROST_KEY },
    });
    if (!res.ok) return null;
    return res.json();
  } catch { return null; }
}

/**
 * Get UTXO details for a transaction
 */
async function getTransactionUtxos(txHash) {
  if (!BLOCKFROST_KEY) return null;
  try {
    const res = await fetch(`${BLOCKFROST_API}/txs/${txHash}/utxos`, {
      headers: { 'project_id': BLOCKFROST_KEY },
    });
    if (!res.ok) return null;
    return res.json();
  } catch { return null; }
}

/**
 * Check if an address has received a specific ADA amount.
 * Returns the matching tx hash or null.
 */
async function checkPaymentReceived(address, expectedLovelace) {
  const { transactions, mock } = await getAddressTransactions(address);
  if (mock || transactions.length === 0) return null;

  for (const tx of transactions) {
    const utxos = await getTransactionUtxos(tx.tx_hash);
    if (!utxos) continue;

    for (const output of utxos.outputs) {
      if (output.address === address) {
        const lovelace = output.amount.find(a => a.unit === 'lovelace');
        if (lovelace && BigInt(lovelace.quantity) >= BigInt(expectedLovelace)) {
          return {
            txHash: tx.tx_hash,
            amount: Number(BigInt(lovelace.quantity)) / 1000000,
            block: tx.block_height,
            confirmations: 0, // Would need current block height to calculate
          };
        }
      }
    }
  }
  return null;
}

/**
 * Validate a Cardano address format
 */
function isValidAddress(address) {
  if (!address) return false;
  // Shelley mainnet: addr1...
  // Shelley testnet: addr_test1...
  // Byron: Ae2... or DdzFF...
  return /^addr1[a-zA-Z0-9]{50,120}$/.test(address)
    || /^addr_test1[a-zA-Z0-9]{50,120}$/.test(address)
    || /^(Ae2|DdzFF)[a-zA-Z0-9]+$/.test(address);
}

module.exports = {
  fetchPrice,
  fiatToAda,
  adaToFiat,
  getPrices,
  generatePaymentAddress,
  getAddressTransactions,
  getTransaction,
  getTransactionUtxos,
  checkPaymentReceived,
  isValidAddress,
};
