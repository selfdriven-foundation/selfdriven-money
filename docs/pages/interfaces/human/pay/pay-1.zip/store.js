// ═══════════════════════════════════════════════════════════════
// lib/store.js — In-memory data store for selfdriven.money/pay
// Manages payments, API keys, webhooks, merchants, and settings.
// In production: replace with PostgreSQL / Redis.
// ═══════════════════════════════════════════════════════════════
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data.json');

class PaymentStore {
  constructor() {
    this.payments = new Map();
    this.apiKeys = new Map();
    this.webhooks = new Map();
    this.merchants = new Map();
    this.settings = new Map();
    this.keriEvents = []; // Append-only KEL
    this._load();
  }

  // ─── Persistence ───────────────────────────────────
  _load() {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        if (raw.payments) raw.payments.forEach(([k, v]) => this.payments.set(k, v));
        if (raw.apiKeys) raw.apiKeys.forEach(([k, v]) => this.apiKeys.set(k, v));
        if (raw.webhooks) raw.webhooks.forEach(([k, v]) => this.webhooks.set(k, v));
        if (raw.merchants) raw.merchants.forEach(([k, v]) => this.merchants.set(k, v));
        if (raw.settings) raw.settings.forEach(([k, v]) => this.settings.set(k, v));
        if (raw.keriEvents) this.keriEvents = raw.keriEvents;
        console.log(`[store] Loaded ${this.payments.size} payments, ${this.apiKeys.size} API keys`);
      }
    } catch (e) {
      console.warn('[store] Could not load data file, starting fresh:', e.message);
    }
  }

  _save() {
    try {
      const data = {
        payments: [...this.payments],
        apiKeys: [...this.apiKeys],
        webhooks: [...this.webhooks],
        merchants: [...this.merchants],
        settings: [...this.settings],
        keriEvents: this.keriEvents,
      };
      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
      console.error('[store] Save failed:', e.message);
    }
  }

  // ─── Payments ──────────────────────────────────────
  createPayment(data) {
    const id = 'pay_' + crypto.randomBytes(6).toString('base64url');
    const payment = {
      id,
      merchantId: data.merchantId || 'default',
      amount: data.amount,
      currency: data.currency || 'ADA',
      amountAda: data.amountAda,
      fiatValue: data.fiatValue || null,
      fiatCurrency: data.fiatCurrency || null,
      description: data.description || '',
      customerEmail: data.customerEmail || null,
      metadata: data.metadata || {},
      address: data.address,
      status: 'pending',
      expiryMinutes: data.expiryMinutes || 30,
      expiresAt: data.expiryMinutes > 0
        ? new Date(Date.now() + data.expiryMinutes * 60000).toISOString()
        : null,
      txHash: null,
      confirmations: 0,
      keriEvent: data.keriEvent || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.payments.set(id, payment);
    this._save();
    return payment;
  }

  getPayment(id) {
    return this.payments.get(id) || null;
  }

  listPayments(filters = {}) {
    let results = [...this.payments.values()];
    if (filters.status) results = results.filter(p => p.status === filters.status);
    if (filters.merchantId) results = results.filter(p => p.merchantId === filters.merchantId);
    results.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const page = filters.page || 1;
    const limit = filters.limit || 20;
    const start = (page - 1) * limit;
    const paged = results.slice(start, start + limit);

    return {
      data: paged,
      meta: {
        totalRecords: results.length,
        totalPages: Math.ceil(results.length / limit),
        page,
        limit,
      },
      links: {
        self: `?page=${page}&limit=${limit}`,
        first: `?page=1&limit=${limit}`,
        last: `?page=${Math.ceil(results.length / limit)}&limit=${limit}`,
        next: start + limit < results.length ? `?page=${page + 1}&limit=${limit}` : null,
      },
    };
  }

  updatePayment(id, updates) {
    const payment = this.payments.get(id);
    if (!payment) return null;
    Object.assign(payment, updates, { updatedAt: new Date().toISOString() });
    this.payments.set(id, payment);
    this._save();
    return payment;
  }

  // ─── API Keys ──────────────────────────────────────
  createApiKey(data) {
    const prefix = data.testMode ? 'sd_test_' : 'sd_live_';
    const secret = prefix + crypto.randomBytes(24).toString('base64url');
    const hash = crypto.createHash('sha256').update(secret).digest('hex');
    const record = {
      id: 'key_' + crypto.randomBytes(4).toString('hex'),
      name: data.name || 'Unnamed Key',
      prefix: secret.substring(0, prefix.length + 8),
      hash,
      merchantId: data.merchantId || 'default',
      testMode: !!data.testMode,
      keriAgentAid: data.keriAgentAid || null,
      keriEvent: data.keriEvent || null,
      scopes: data.scopes || ['payments:read', 'payments:write'],
      createdAt: new Date().toISOString(),
      lastUsedAt: null,
    };
    this.apiKeys.set(hash, record);
    this._save();
    return { ...record, secret }; // only return secret once
  }

  validateApiKey(key) {
    const hash = crypto.createHash('sha256').update(key).digest('hex');
    const record = this.apiKeys.get(hash);
    if (!record) return null;
    record.lastUsedAt = new Date().toISOString();
    this.apiKeys.set(hash, record);
    return record;
  }

  listApiKeys(merchantId) {
    return [...this.apiKeys.values()]
      .filter(k => !merchantId || k.merchantId === merchantId)
      .map(k => ({ ...k, hash: undefined })); // never expose hash
  }

  deleteApiKey(keyId) {
    for (const [hash, record] of this.apiKeys) {
      if (record.id === keyId) {
        this.apiKeys.delete(hash);
        this._save();
        return true;
      }
    }
    return false;
  }

  // ─── Webhooks ──────────────────────────────────────
  createWebhook(data) {
    const id = 'whk_' + crypto.randomBytes(4).toString('hex');
    const secret = 'whsec_' + crypto.randomBytes(16).toString('base64url');
    const webhook = {
      id,
      url: data.url,
      events: data.events || ['payment.confirmed', 'payment.expired', 'payment.pending'],
      secret,
      merchantId: data.merchantId || 'default',
      active: true,
      createdAt: new Date().toISOString(),
      lastDelivery: null,
      failCount: 0,
    };
    this.webhooks.set(id, webhook);
    this._save();
    return webhook;
  }

  listWebhooks(merchantId) {
    return [...this.webhooks.values()]
      .filter(w => !merchantId || w.merchantId === merchantId);
  }

  getWebhooksByEvent(event, merchantId) {
    return [...this.webhooks.values()]
      .filter(w => w.active && w.events.includes(event))
      .filter(w => !merchantId || w.merchantId === merchantId);
  }

  updateWebhook(id, updates) {
    const wh = this.webhooks.get(id);
    if (!wh) return null;
    Object.assign(wh, updates);
    this.webhooks.set(id, wh);
    this._save();
    return wh;
  }

  deleteWebhook(id) {
    const deleted = this.webhooks.delete(id);
    if (deleted) this._save();
    return deleted;
  }

  // ─── Settings ──────────────────────────────────────
  getSettings(merchantId = 'default') {
    return this.settings.get(merchantId) || {
      merchantId,
      businessName: 'selfdriven.services',
      payoutAddress: 'addr1qx2kd28nq8ac5prwg32hhvudlwggpgfp8utlyqxu2a3genj2f6yt7m8h8r9ahx2rl5p06lxpgek8hxqrs3jxk5q9gvz6q4u79c5',
      autoConvert: false,
      autoConvertCurrency: 'AUD',
      emailNotifications: true,
      keriWitnessing: true,
      nativeTokenSupport: true,
      stakingOnReceipt: false,
      stakePoolId: null,
      testMode: false,
      keriAid: 'EKE4g_0hDGBOqDLKzNBT3kFOPxoP7wXkqt',
    };
  }

  updateSettings(merchantId, updates) {
    const current = this.getSettings(merchantId);
    const updated = { ...current, ...updates, merchantId };
    this.settings.set(merchantId, updated);
    this._save();
    return updated;
  }

  // ─── KERI Event Log ────────────────────────────────
  appendKeriEvent(event) {
    this.keriEvents.push({
      ...event,
      recordedAt: new Date().toISOString(),
    });
    this._save();
  }

  getKeriEvents(aid, limit = 50) {
    return this.keriEvents
      .filter(e => !aid || e.aid === aid)
      .slice(-limit);
  }

  // ─── Stats ─────────────────────────────────────────
  getStats(merchantId) {
    const payments = [...this.payments.values()]
      .filter(p => !merchantId || p.merchantId === merchantId);

    const confirmed = payments.filter(p => p.status === 'confirmed');
    const pending = payments.filter(p => p.status === 'pending');

    const totalRevenue = confirmed.reduce((sum, p) => sum + (p.amountAda || p.amount), 0);
    const avgPayment = confirmed.length > 0 ? totalRevenue / confirmed.length : 0;
    const successRate = payments.length > 0
      ? (confirmed.length / payments.length * 100)
      : 0;

    // Volume by day (last 30 days)
    const now = Date.now();
    const dailyVolume = [];
    for (let i = 29; i >= 0; i--) {
      const dayStart = new Date(now - i * 86400000);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(dayStart.getTime() + 86400000);
      const dayPayments = confirmed.filter(p => {
        const d = new Date(p.createdAt);
        return d >= dayStart && d < dayEnd;
      });
      dailyVolume.push({
        date: dayStart.toISOString().split('T')[0],
        count: dayPayments.length,
        volume: dayPayments.reduce((s, p) => s + (p.amountAda || p.amount), 0),
      });
    }

    return {
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      totalTransactions: payments.length,
      confirmedTransactions: confirmed.length,
      pendingTransactions: pending.length,
      avgPayment: Math.round(avgPayment * 100) / 100,
      successRate: Math.round(successRate * 10) / 10,
      dailyVolume,
    };
  }
}

module.exports = new PaymentStore();
