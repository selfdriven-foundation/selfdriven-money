#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════
// server.js — selfdriven.money/pay API Server
// Non-custodial Cardano payment gateway with KERI identity layer
//
// Architecture:
//   Express.js + in-memory store + Blockfrost Cardano API
//   KERI interaction events anchor every payment mutation
//   Webhook delivery with HMAC-SHA256 signatures
//   QR code generation for checkout pages
//
// Endpoints:
//   Public:     GET  /health
//               GET  /api/v1/prices
//               GET  /api/v1/checkout/:paymentId
//               GET  /api/v1/checkout/:paymentId/qr
//               GET  /api/v1/checkout/:paymentId/status
//
//   Auth (API key):
//     Payments: POST /api/v1/payments
//               GET  /api/v1/payments
//               GET  /api/v1/payments/:id
//               POST /api/v1/payments/:id/confirm  (simulate/manual)
//               POST /api/v1/payments/:id/expire
//
//     Keys:     POST /api/v1/api-keys
//               GET  /api/v1/api-keys
//               DELETE /api/v1/api-keys/:id
//
//     Webhooks: POST /api/v1/webhooks
//               GET  /api/v1/webhooks
//               DELETE /api/v1/webhooks/:id
//               POST /api/v1/webhooks/:id/test
//
//     Settings: GET  /api/v1/settings
//               PUT  /api/v1/settings
//
//     Stats:    GET  /api/v1/stats
//
//     KERI:     GET  /api/v1/identity/kel
//               GET  /api/v1/identity/aid
//
//   Dashboard:  GET  / (serves the HTML dashboard)
// ═══════════════════════════════════════════════════════════════

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const crypto = require('crypto');
const path = require('path');
const QRCode = require('qrcode');

const store = require('./lib/store');
const keri = require('./lib/keri');
const cardano = require('./lib/cardano');
const webhooks = require('./lib/webhooks');

const app = express();
const PORT = process.env.PORT || 3000;

// ═══════════════════════════════════════════════════════════════
// MIDDLEWARE
// ═══════════════════════════════════════════════════════════════

app.use(express.json({ limit: '1mb' }));
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-KERI-AID', 'X-Request-ID'],
}));
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://api.coingecko.com"],
    },
  },
}));

// Request ID middleware
app.use((req, res, next) => {
  req.requestId = req.headers['x-request-id'] || crypto.randomBytes(8).toString('hex');
  res.setHeader('X-Request-ID', req.requestId);
  res.setHeader('X-Powered-By', 'selfdriven.money/pay');
  next();
});

// Request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (!req.path.includes('/health') && !req.path.includes('.')) {
      console.log(`[${req.method}] ${req.path} → ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// Rate limiting (simple in-memory)
const rateLimits = new Map();
function rateLimit(windowMs, maxRequests) {
  return (req, res, next) => {
    const key = req.ip + ':' + req.path;
    const now = Date.now();
    const record = rateLimits.get(key) || { count: 0, resetAt: now + windowMs };
    if (now > record.resetAt) {
      record.count = 0;
      record.resetAt = now + windowMs;
    }
    record.count++;
    rateLimits.set(key, record);
    res.setHeader('X-RateLimit-Limit', maxRequests);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, maxRequests - record.count));
    if (record.count > maxRequests) {
      return res.status(429).json({ error: 'Rate limit exceeded', retryAfter: Math.ceil((record.resetAt - now) / 1000) });
    }
    next();
  };
}

// ─── API Key Authentication Middleware ────────────────
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Authentication required',
      message: 'Provide API key via Authorization: Bearer sd_live_...',
    });
  }

  const apiKey = authHeader.substring(7);
  const keyRecord = store.validateApiKey(apiKey);

  // Also allow a master key from env for initial setup
  const masterKey = process.env.MASTER_API_KEY || 'sd_live_MASTER_KEY_CHANGE_ME';
  if (!keyRecord && apiKey !== masterKey) {
    return res.status(403).json({ error: 'Invalid API key' });
  }

  req.merchantId = keyRecord?.merchantId || 'default';
  req.apiKeyRecord = keyRecord;
  req.keriAid = req.headers['x-keri-aid'] || keri.DEFAULT_AID;
  next();
}

// ─── Static files ─────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ═══════════════════════════════════════════════════════════════
// PUBLIC ENDPOINTS
// ═══════════════════════════════════════════════════════════════

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'selfdriven.money/pay',
    version: '1.0.0',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    components: {
      api: 'healthy',
      store: 'healthy',
      keri: 'healthy',
      blockfrost: process.env.BLOCKFROST_API_KEY ? 'connected' : 'mock-mode',
    },
  });
});

// ADA Prices
app.get('/api/v1/prices', rateLimit(60000, 30), async (req, res) => {
  try {
    const prices = await cardano.getPrices();
    res.json({
      data: {
        ada: {
          usd: prices.ada_usd,
          aud: prices.ada_aud,
          eur: prices.ada_eur,
          gbp: prices.ada_gbp,
        },
        updatedAt: new Date(prices.updatedAt).toISOString(),
      },
    });
  } catch (e) {
    res.status(500).json({ error: 'Price fetch failed', message: e.message });
  }
});

// ─── Checkout (public, customer-facing) ───────────────

// Get checkout details for a payment
app.get('/api/v1/checkout/:paymentId', rateLimit(60000, 60), (req, res) => {
  const payment = store.getPayment(req.params.paymentId);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });

  // Check expiry
  if (payment.expiresAt && new Date(payment.expiresAt) < new Date() && payment.status === 'pending') {
    store.updatePayment(payment.id, { status: 'expired' });
    payment.status = 'expired';
    // Fire webhook
    webhooks.dispatch('payment.expired', payment);
    // KERI event
    const keriEvt = keri.createInteractionEvent(payment.keriEvent?.aid, {
      paymentId: payment.id, amount: payment.amountAda || payment.amount,
      action: 'expired',
    });
    store.appendKeriEvent(keriEvt);
  }

  // Public view — hide sensitive fields
  res.json({
    data: {
      id: payment.id,
      amount: payment.amountAda || payment.amount,
      currency: 'ADA',
      fiatValue: payment.fiatValue,
      fiatCurrency: payment.fiatCurrency,
      description: payment.description,
      address: payment.address,
      status: payment.status,
      expiresAt: payment.expiresAt,
      createdAt: payment.createdAt,
      txHash: payment.txHash,
      confirmations: payment.confirmations,
      merchantName: store.getSettings(payment.merchantId).businessName,
      cardanoUri: `web+cardano:${payment.address}?amount=${(payment.amountAda || payment.amount) * 1000000}`,
    },
  });
});

// Get QR code for a payment
app.get('/api/v1/checkout/:paymentId/qr', rateLimit(60000, 60), async (req, res) => {
  const payment = store.getPayment(req.params.paymentId);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });

  const adaAmount = payment.amountAda || payment.amount;
  const uri = `web+cardano:${payment.address}?amount=${adaAmount * 1000000}`;
  const format = req.query.format || 'png';

  try {
    if (format === 'svg') {
      const svg = await QRCode.toString(uri, {
        type: 'svg',
        color: { dark: '#1a1410', light: '#ffffff' },
        margin: 2,
        width: 256,
      });
      res.setHeader('Content-Type', 'image/svg+xml');
      res.send(svg);
    } else {
      const buffer = await QRCode.toBuffer(uri, {
        type: 'png',
        color: { dark: '#1a1410', light: '#ffffff' },
        margin: 2,
        width: parseInt(req.query.size) || 256,
        errorCorrectionLevel: 'M',
      });
      res.setHeader('Content-Type', 'image/png');
      res.send(buffer);
    }
  } catch (e) {
    res.status(500).json({ error: 'QR generation failed', message: e.message });
  }
});

// Poll payment status (for checkout page polling)
app.get('/api/v1/checkout/:paymentId/status', rateLimit(10000, 30), (req, res) => {
  const payment = store.getPayment(req.params.paymentId);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });

  // Check expiry
  if (payment.expiresAt && new Date(payment.expiresAt) < new Date() && payment.status === 'pending') {
    store.updatePayment(payment.id, { status: 'expired' });
    payment.status = 'expired';
  }

  res.json({
    data: {
      id: payment.id,
      status: payment.status,
      txHash: payment.txHash,
      confirmations: payment.confirmations,
      expiresAt: payment.expiresAt,
    },
  });
});

// ═══════════════════════════════════════════════════════════════
// AUTHENTICATED ENDPOINTS
// ═══════════════════════════════════════════════════════════════

// ─── Payments ─────────────────────────────────────────

// Create a new payment
app.post('/api/v1/payments', requireAuth, rateLimit(60000, 100), async (req, res) => {
  try {
    const { amount, currency, description, customer_email, expiry_minutes, metadata, callback_url } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount', message: 'amount must be > 0' });
    }

    // Convert fiat to ADA if needed
    let amountAda = amount;
    let fiatValue = null;
    let fiatCurrency = null;

    const curr = (currency || 'ADA').toUpperCase();
    if (curr !== 'ADA') {
      amountAda = await cardano.fiatToAda(amount, curr);
      fiatValue = amount;
      fiatCurrency = curr;
    } else {
      // Calculate fiat equivalent
      fiatValue = await cardano.adaToFiat(amount, 'USD');
      fiatCurrency = 'USD';
    }

    // Generate unique receiving address
    const settings = store.getSettings(req.merchantId);
    const paymentId = 'pay_' + crypto.randomBytes(6).toString('base64url');
    const address = cardano.generatePaymentAddress(paymentId, settings.payoutAddress);

    // Create KERI interaction event
    const keriEvent = keri.createInteractionEvent(req.keriAid, {
      paymentId,
      amount: amountAda,
      currency: 'ADA',
      action: 'created',
    });
    store.appendKeriEvent(keriEvent);

    // Store payment
    const payment = store.createPayment({
      merchantId: req.merchantId,
      amount: amountAda,
      currency: 'ADA',
      amountAda,
      fiatValue,
      fiatCurrency,
      description: description || '',
      customerEmail: customer_email,
      metadata: metadata || {},
      address,
      expiryMinutes: expiry_minutes !== undefined ? expiry_minutes : 30,
      keriEvent: {
        type: keriEvent.type,
        aid: keriEvent.aid,
        sn: keriEvent.sn,
        digest: keriEvent.digest,
      },
    });
    // Override the auto-generated ID with our pre-generated one
    store.payments.delete(payment.id);
    payment.id = paymentId;
    store.payments.set(paymentId, payment);

    // Register callback as webhook if provided
    if (callback_url) {
      store.createWebhook({
        url: callback_url,
        events: ['payment.confirmed', 'payment.expired'],
        merchantId: req.merchantId,
      });
    }

    // Dispatch webhook
    webhooks.dispatch('payment.created', payment);

    console.log(`[payment] Created ${paymentId}: ${amountAda} ADA → ${address.substring(0, 20)}...`);

    res.status(201).json({
      data: {
        payment_id: payment.id,
        amount: payment.amountAda,
        currency: 'ADA',
        fiat_value: payment.fiatValue,
        fiat_currency: payment.fiatCurrency,
        description: payment.description,
        address: payment.address,
        status: payment.status,
        expires_at: payment.expiresAt,
        checkout_url: `${req.protocol}://${req.get('host')}/checkout/${payment.id}`,
        qr_url: `${req.protocol}://${req.get('host')}/api/v1/checkout/${payment.id}/qr`,
        cardano_uri: `web+cardano:${payment.address}?amount=${Math.round(amountAda * 1000000)}`,
        keriEvent: payment.keriEvent,
        created_at: payment.createdAt,
      },
      links: {
        self: `/api/v1/payments/${payment.id}`,
        checkout: `/api/v1/checkout/${payment.id}`,
        qr: `/api/v1/checkout/${payment.id}/qr`,
        status: `/api/v1/checkout/${payment.id}/status`,
      },
    });
  } catch (e) {
    console.error('[payment] Create failed:', e);
    res.status(500).json({ error: 'Payment creation failed', message: e.message });
  }
});

// List payments
app.get('/api/v1/payments', requireAuth, (req, res) => {
  const result = store.listPayments({
    merchantId: req.merchantId,
    status: req.query.status,
    page: parseInt(req.query.page) || 1,
    limit: parseInt(req.query.limit) || 20,
  });

  res.json({
    data: result.data.map(p => ({
      id: p.id,
      amount: p.amountAda || p.amount,
      currency: p.currency,
      fiat_value: p.fiatValue,
      fiat_currency: p.fiatCurrency,
      description: p.description,
      status: p.status,
      tx_hash: p.txHash,
      confirmations: p.confirmations,
      address: p.address,
      keriEvent: p.keriEvent,
      created_at: p.createdAt,
      updated_at: p.updatedAt,
    })),
    meta: result.meta,
    links: result.links,
  });
});

// Get single payment
app.get('/api/v1/payments/:id', requireAuth, (req, res) => {
  const payment = store.getPayment(req.params.id);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });
  if (payment.merchantId !== req.merchantId && req.merchantId !== 'default') {
    return res.status(403).json({ error: 'Access denied' });
  }

  res.json({
    data: {
      id: payment.id,
      amount: payment.amountAda || payment.amount,
      currency: payment.currency,
      fiat_value: payment.fiatValue,
      fiat_currency: payment.fiatCurrency,
      description: payment.description,
      customer_email: payment.customerEmail,
      metadata: payment.metadata,
      address: payment.address,
      status: payment.status,
      tx_hash: payment.txHash,
      confirmations: payment.confirmations,
      expires_at: payment.expiresAt,
      keriEvent: payment.keriEvent,
      created_at: payment.createdAt,
      updated_at: payment.updatedAt,
    },
  });
});

// Manually confirm a payment (for testing / manual reconciliation)
app.post('/api/v1/payments/:id/confirm', requireAuth, async (req, res) => {
  const payment = store.getPayment(req.params.id);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });
  if (payment.status === 'confirmed') {
    return res.status(409).json({ error: 'Payment already confirmed' });
  }

  const txHash = req.body.tx_hash || 'manual_' + crypto.randomBytes(16).toString('hex');
  const confirmations = req.body.confirmations || 15;

  // KERI event for confirmation
  const keriEvent = keri.createInteractionEvent(req.keriAid, {
    paymentId: payment.id,
    amount: payment.amountAda || payment.amount,
    action: 'confirmed',
    txHash,
    previousDigest: payment.keriEvent?.digest,
  });
  store.appendKeriEvent(keriEvent);

  const updated = store.updatePayment(payment.id, {
    status: 'confirmed',
    txHash,
    confirmations,
    keriEvent: {
      type: keriEvent.type,
      aid: keriEvent.aid,
      sn: keriEvent.sn,
      digest: keriEvent.digest,
    },
  });

  // Dispatch webhooks
  webhooks.dispatch('payment.confirmed', updated);

  console.log(`[payment] Confirmed ${payment.id}: tx=${txHash.substring(0, 16)}...`);

  res.json({
    data: {
      id: updated.id,
      status: updated.status,
      tx_hash: updated.txHash,
      confirmations: updated.confirmations,
      keriEvent: updated.keriEvent,
    },
  });
});

// Expire a payment manually
app.post('/api/v1/payments/:id/expire', requireAuth, (req, res) => {
  const payment = store.getPayment(req.params.id);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });
  if (payment.status !== 'pending') {
    return res.status(409).json({ error: `Cannot expire payment in ${payment.status} state` });
  }

  const keriEvent = keri.createInteractionEvent(req.keriAid, {
    paymentId: payment.id,
    amount: payment.amountAda || payment.amount,
    action: 'expired',
    previousDigest: payment.keriEvent?.digest,
  });
  store.appendKeriEvent(keriEvent);

  const updated = store.updatePayment(payment.id, {
    status: 'expired',
    keriEvent: {
      type: keriEvent.type,
      aid: keriEvent.aid,
      sn: keriEvent.sn,
      digest: keriEvent.digest,
    },
  });

  webhooks.dispatch('payment.expired', updated);
  res.json({ data: { id: updated.id, status: updated.status, keriEvent: updated.keriEvent } });
});

// ─── API Keys ─────────────────────────────────────────

app.post('/api/v1/api-keys', requireAuth, (req, res) => {
  const { name, test_mode, scopes } = req.body;

  // Create KERI delegated inception for the API key agent
  const dipEvent = keri.createDelegatedInceptionEvent(req.keriAid, name || 'API Key');

  const key = store.createApiKey({
    name,
    testMode: test_mode,
    merchantId: req.merchantId,
    scopes,
    keriAgentAid: dipEvent.agentAid,
    keriEvent: dipEvent.event,
  });

  store.appendKeriEvent({
    type: 'dip',
    aid: dipEvent.agentAid,
    delegator: req.keriAid,
    sn: 0,
    digest: dipEvent.event.d,
  });

  console.log(`[api-key] Created ${key.id} (${name}) → agent AID ${dipEvent.agentAid.substring(0, 16)}...`);

  res.status(201).json({
    data: {
      id: key.id,
      name: key.name,
      secret: key.secret, // Only shown once!
      prefix: key.prefix,
      test_mode: key.testMode,
      scopes: key.scopes,
      keri_agent_aid: key.keriAgentAid,
      created_at: key.createdAt,
    },
    warning: 'Store this secret securely — it will not be shown again.',
  });
});

app.get('/api/v1/api-keys', requireAuth, (req, res) => {
  const keys = store.listApiKeys(req.merchantId);
  res.json({
    data: keys.map(k => ({
      id: k.id,
      name: k.name,
      prefix: k.prefix,
      test_mode: k.testMode,
      scopes: k.scopes,
      keri_agent_aid: k.keriAgentAid,
      created_at: k.createdAt,
      last_used_at: k.lastUsedAt,
    })),
  });
});

app.delete('/api/v1/api-keys/:id', requireAuth, (req, res) => {
  const deleted = store.deleteApiKey(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'API key not found' });
  res.json({ data: { deleted: true, id: req.params.id } });
});

// ─── Webhooks ─────────────────────────────────────────

app.post('/api/v1/webhooks', requireAuth, (req, res) => {
  const { url, events } = req.body;
  if (!url) return res.status(400).json({ error: 'url is required' });

  const webhook = store.createWebhook({
    url,
    events,
    merchantId: req.merchantId,
  });

  console.log(`[webhook] Created ${webhook.id} → ${url}`);

  res.status(201).json({
    data: {
      id: webhook.id,
      url: webhook.url,
      events: webhook.events,
      secret: webhook.secret, // Only shown once
      active: webhook.active,
      created_at: webhook.createdAt,
    },
    warning: 'Store the signing secret securely — it will not be shown again.',
  });
});

app.get('/api/v1/webhooks', requireAuth, (req, res) => {
  const whs = store.listWebhooks(req.merchantId);
  res.json({
    data: whs.map(w => ({
      id: w.id,
      url: w.url,
      events: w.events,
      active: w.active,
      created_at: w.createdAt,
      last_delivery: w.lastDelivery,
      fail_count: w.failCount,
    })),
  });
});

app.delete('/api/v1/webhooks/:id', requireAuth, (req, res) => {
  const deleted = store.deleteWebhook(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Webhook not found' });
  res.json({ data: { deleted: true, id: req.params.id } });
});

// Test a webhook endpoint
app.post('/api/v1/webhooks/:id/test', requireAuth, async (req, res) => {
  const wh = store.webhooks.get(req.params.id);
  if (!wh) return res.status(404).json({ error: 'Webhook not found' });

  const testEvent = {
    event: 'payment.test',
    payment_id: 'pay_TEST_000000',
    amount: 100,
    currency: 'ADA',
    status: 'confirmed',
    tx_hash: 'test_' + crypto.randomBytes(16).toString('hex'),
    keriEvent: {
      type: 'ixn',
      aid: keri.DEFAULT_AID,
      sn: Date.now(),
      digest: keri.digest('test'),
    },
    timestamp: new Date().toISOString(),
  };

  const result = await webhooks.deliverToEndpoint(wh, testEvent);
  res.json({ data: { delivered: result, url: wh.url, event: testEvent } });
});

// ─── Settings ─────────────────────────────────────────

app.get('/api/v1/settings', requireAuth, (req, res) => {
  const settings = store.getSettings(req.merchantId);
  res.json({ data: settings });
});

app.put('/api/v1/settings', requireAuth, (req, res) => {
  const allowedFields = [
    'businessName', 'payoutAddress', 'autoConvert', 'autoConvertCurrency',
    'emailNotifications', 'keriWitnessing', 'nativeTokenSupport',
    'stakingOnReceipt', 'stakePoolId', 'testMode',
  ];

  const updates = {};
  for (const field of allowedFields) {
    if (req.body[field] !== undefined) {
      // Validate payout address
      if (field === 'payoutAddress' && !cardano.isValidAddress(req.body[field])) {
        return res.status(400).json({ error: 'Invalid Cardano address' });
      }
      updates[field] = req.body[field];
    }
  }

  const settings = store.updateSettings(req.merchantId, updates);

  // KERI event for settings change
  const keriEvent = keri.createInteractionEvent(req.keriAid, {
    paymentId: 'settings',
    amount: 0,
    action: 'settings_updated',
  });
  store.appendKeriEvent(keriEvent);

  res.json({ data: settings, keriEvent: { type: keriEvent.type, sn: keriEvent.sn, digest: keriEvent.digest } });
});

// ─── Stats ────────────────────────────────────────────

app.get('/api/v1/stats', requireAuth, (req, res) => {
  const stats = store.getStats(req.merchantId);
  res.json({ data: stats });
});

// ─── KERI Identity ────────────────────────────────────

app.get('/api/v1/identity/aid', requireAuth, (req, res) => {
  const settings = store.getSettings(req.merchantId);
  res.json({
    data: {
      aid: settings.keriAid || keri.DEFAULT_AID,
      merchantId: req.merchantId,
      witnesses: [
        'BGKVzj4ve0VSd8z_AmvhLg0lqcE2l_E5_Lb0lTV7GmME',
        'BuyRFMideczFZoapylLIyCjSdhtqVb31wZkRKvPFNTkw3',
        'Bgoq68HCmYNUDgOz4Skvlu306o_NY-NrYuKAVhk3Zh9c',
      ],
      witnessThreshold: 2,
      status: 'verified',
    },
  });
});

app.get('/api/v1/identity/kel', requireAuth, (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  const aid = req.query.aid || req.keriAid;
  const events = store.getKeriEvents(aid, limit);
  res.json({
    data: events,
    meta: { aid, count: events.length, limit },
  });
});

// ─── Checkout page (serves HTML) ──────────────────────
app.get('/checkout/:paymentId', (req, res) => {
  // Serve the main dashboard HTML — the frontend handles routing
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Fallback — serve dashboard for all unmatched routes
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Endpoint not found' });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ═══════════════════════════════════════════════════════════════
// BACKGROUND: Payment Monitor
// Periodically checks pending payments for:
//   1. Incoming transactions (via Blockfrost)
//   2. Expiry
// ═══════════════════════════════════════════════════════════════
function startPaymentMonitor() {
  const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL) || 30000; // 30s

  setInterval(async () => {
    const pending = [...store.payments.values()].filter(p => p.status === 'pending');
    if (pending.length === 0) return;

    for (const payment of pending) {
      // Check expiry
      if (payment.expiresAt && new Date(payment.expiresAt) < new Date()) {
        console.log(`[monitor] Payment ${payment.id} expired`);
        const keriEvent = keri.createInteractionEvent(payment.keriEvent?.aid || keri.DEFAULT_AID, {
          paymentId: payment.id,
          amount: payment.amountAda || payment.amount,
          action: 'expired',
          previousDigest: payment.keriEvent?.digest,
        });
        store.appendKeriEvent(keriEvent);
        store.updatePayment(payment.id, {
          status: 'expired',
          keriEvent: { type: keriEvent.type, aid: keriEvent.aid, sn: keriEvent.sn, digest: keriEvent.digest },
        });
        webhooks.dispatch('payment.expired', store.getPayment(payment.id));
        continue;
      }

      // Check for on-chain payment (only if Blockfrost configured)
      if (process.env.BLOCKFROST_API_KEY) {
        try {
          const lovelace = Math.round((payment.amountAda || payment.amount) * 1000000);
          const result = await cardano.checkPaymentReceived(payment.address, lovelace);
          if (result) {
            console.log(`[monitor] Payment ${payment.id} confirmed: ${result.txHash}`);
            const keriEvent = keri.createInteractionEvent(payment.keriEvent?.aid || keri.DEFAULT_AID, {
              paymentId: payment.id,
              amount: payment.amountAda || payment.amount,
              action: 'confirmed',
              txHash: result.txHash,
              previousDigest: payment.keriEvent?.digest,
            });
            store.appendKeriEvent(keriEvent);
            store.updatePayment(payment.id, {
              status: 'confirmed',
              txHash: result.txHash,
              confirmations: result.confirmations || 15,
              keriEvent: { type: keriEvent.type, aid: keriEvent.aid, sn: keriEvent.sn, digest: keriEvent.digest },
            });
            webhooks.dispatch('payment.confirmed', store.getPayment(payment.id));
          }
        } catch (e) {
          console.warn(`[monitor] Check failed for ${payment.id}:`, e.message);
        }
      }
    }
  }, POLL_INTERVAL);

  console.log(`[monitor] Payment monitor started (interval: ${POLL_INTERVAL}ms)`);
}

// ═══════════════════════════════════════════════════════════════
// SEED: Demo data for first run
// ═══════════════════════════════════════════════════════════════
function seedDemoData() {
  if (store.payments.size > 0) return; // Already has data

  console.log('[seed] Seeding demo data...');

  // Create default API keys
  store.createApiKey({ name: 'Production', merchantId: 'default', testMode: false });
  store.createApiKey({ name: 'Test', merchantId: 'default', testMode: true });

  // Create default webhook
  store.createWebhook({
    url: 'https://api.yoursite.com/webhooks/payments',
    events: ['payment.confirmed', 'payment.expired', 'payment.pending'],
    merchantId: 'default',
  });

  // Seed demo payments
  const demoPayments = [
    { desc: 'Invoice #1042 — Web Dev', amount: 250, status: 'confirmed', daysAgo: 0, hash: '8f2a7b3cd9e1f4a6b8c2d5e7f3a1b9c4d1e6f8a2b4c7d9e1f3a5b7c9d2e4f6a8' },
    { desc: 'Premium Subscription', amount: 45, status: 'confirmed', daysAgo: 0, hash: 'a1c4e8f27b3d9c6e2a5f1b8d4c7e3a9f6b2d8e1c5a7f3b9d6e2a4c8f1b7d3e5' },
    { desc: 'Consulting Hour — March', amount: 120, status: 'pending', daysAgo: 0, hash: null },
    { desc: 'Design Assets Pack', amount: 85, status: 'confirmed', daysAgo: 1, hash: 'f3d9a2b1e8c74f6d3a9b2e1c5f8d7a4b6e3c9f2d1a8b5e7c4f6a3d9b2e1c8f7' },
    { desc: 'API Integration Support', amount: 300, status: 'confirmed', daysAgo: 1, hash: 'b7e1c5d84a9f3b6e2d8c1a5f7b4e9d3c6a8f2b1e5d7c4a9f6b3e2d1c8a5f7b4' },
    { desc: 'Hosting — Q1 2026', amount: 180, status: 'confirmed', daysAgo: 2, hash: 'c2a8f6e31d5b7c4a9f2e6b3d8c1a5f7e4b9d2c6a3f8b1e5d7c4a9f6b3e2d1c8' },
    { desc: 'NFT Minting Service', amount: 50, status: 'expired', daysAgo: 2, hash: null },
    { desc: 'Smart Contract Audit', amount: 500, status: 'confirmed', daysAgo: 3, hash: 'd5b3e9a78f2c1d6a4b9e3c7f2a8d5b1e6c4a9f3b7e2d8c1a5f6b4e9d3c7a2f8' },
    { desc: 'Monthly Retainer', amount: 400, status: 'confirmed', daysAgo: 4, hash: 'e8c1d4f62a7b3e9d5c8a1f4b6e2d7c3a9f5b8e1d4c6a2f7b3e9d5c8a1f4b6e2' },
    { desc: 'Workshop Registration', amount: 35, status: 'confirmed', daysAgo: 5, hash: 'a4f7b2c95e3d1a8f6b4c9e7d2a5f3b8c1e6d4a9f7b2c5e3d8a1f6b4c9e7d2a5' },
    { desc: 'Logo Design', amount: 150, status: 'confirmed', daysAgo: 6, hash: 'c9d3e5a17f4b2e8c6a9d1f3b5e7c4a2d8f6b9e1c3a5d7f2b4e8c6a9d1f3b5e7' },
    { desc: 'KERI Integration Setup', amount: 275, status: 'confirmed', daysAgo: 7, hash: 'b2e6a8f43c9d1b5e7a2f6c8d4b9e3a1f5c7d2b8e6a4f9c3d1b5e7a2f6c8d4b9' },
  ];

  for (const dp of demoPayments) {
    const date = new Date(Date.now() - dp.daysAgo * 86400000 - Math.random() * 43200000);
    const address = 'addr1qx2kd28nq8ac5prwg32hhvudlwggpgfp8utlyqxu2a3genj2f6yt7m8h8r9ahx2rl5p06lxpgek8hxqrs3jxk5q9gvz6q4u79c5';

    const keriEvt = keri.createInteractionEvent(keri.DEFAULT_AID, {
      paymentId: 'seed',
      amount: dp.amount,
      action: dp.status === 'pending' ? 'created' : dp.status,
    });

    const payment = store.createPayment({
      merchantId: 'default',
      amount: dp.amount,
      amountAda: dp.amount,
      currency: 'ADA',
      fiatValue: Math.round(dp.amount * 0.70 * 100) / 100,
      fiatCurrency: 'USD',
      description: dp.desc,
      address,
      expiryMinutes: dp.status === 'expired' ? 1 : 30,
      metadata: {},
      keriEvent: {
        type: keriEvt.type,
        aid: keriEvt.aid,
        sn: keriEvt.sn,
        digest: keriEvt.digest,
      },
    });

    // Backdate and set status
    store.updatePayment(payment.id, {
      status: dp.status,
      txHash: dp.hash,
      confirmations: dp.status === 'confirmed' ? 15 : 0,
      createdAt: date.toISOString(),
      updatedAt: date.toISOString(),
    });
  }

  console.log(`[seed] Created ${demoPayments.length} demo payments`);
}

// ═══════════════════════════════════════════════════════════════
// START SERVER
// ═══════════════════════════════════════════════════════════════
seedDemoData();
startPaymentMonitor();

app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║   selfdriven.money/pay — Cardano Payment Gateway      ║
║                                                       ║
║   Server:     http://localhost:${PORT}                  ║
║   API:        http://localhost:${PORT}/api/v1            ║
║   Health:     http://localhost:${PORT}/health            ║
║   Dashboard:  http://localhost:${PORT}/                  ║
║                                                       ║
║   KERI AID:   ${keri.DEFAULT_AID}  ║
║   Blockfrost: ${process.env.BLOCKFROST_API_KEY ? 'Connected' : 'Mock mode (set BLOCKFROST_API_KEY)'}${''.padEnd(process.env.BLOCKFROST_API_KEY ? 30 : 7)}║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
